﻿[System.Serializable]
public class ActionStorage {

    public System.Action action;

}
