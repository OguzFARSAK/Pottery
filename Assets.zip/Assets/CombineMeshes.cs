﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using UnityEngine.UI; 
public class CombineMeshes : MonoBehaviour
{ 
	public MeshFilter mesh;
	public Text text;
	public Image image;
	public LayerMask cullingMask = -1;
	Vector3[] vertexMesh;
	public float distance = 0.1f;
	int count;
	private int mask = -1;

	private int startPer;
	private int last;

	void Start()
	{
		vertexMesh = mesh.mesh.vertices;
		startPer = count;
	}

	public void Calculate()
	{

		count = 0;
		mask = 0 | cullingMask;
		foreach (Vector3 v in vertexMesh)
		{
			Vector2 direction = (transform.TransformPoint(v)) - Camera.main.transform.position;

			RaycastHit2D hit = Physics2D.Raycast(transform.TransformPoint(v), Vector2.right, distance, cullingMask);

			if (hit.collider)
			{
				count++;
			}

		}
		if (last != count)
		{
            
			text.text = ("%" + (100 * count / vertexMesh.Length).ToString());
			last = count;
            image.fillAmount = ((float)count / (float)vertexMesh.Length);
            Debug.Log(((float)count / vertexMesh.Length));
		}
	}


	//public List<GameObject> objs = new List<GameObject>();
	//public void CalculateRemainArea()
	//{

	//    foreach (GameObject g in objs)
	//    {
	//        CSG_Model result = Boolean.Union(gameObject, g);
	//        GetComponent<MeshFilter>().mesh = result.mesh;
	//    }


	//    Debug.Log(CalculateSurfaceArea(GetComponent<MeshFilter>().mesh));
	//}

	//float CalculateSurfaceArea(Mesh mesh)
	//{
	//    var triangles = mesh.triangles;
	//    var vertices = mesh.vertices;

	//    double sum = 0.0;

	//    for (int i = 0; i < triangles.Length; i += 3)
	//    {
	//        Vector3 corner = vertices[triangles[i]];
	//        Vector3 a = vertices[triangles[i + 1]] - corner;
	//        Vector3 b = vertices[triangles[i + 2]] - corner;

	//        sum += Vector3.Cross(a, b).magnitude;
	//    }

	//    return (float)(sum / 2.0);
	//}
} 
