﻿using UnityEngine;
using System.Collections; 

public class DragDrop : MonoBehaviour
{

    private Vector3 offset;

    void Start()
    {
        Application.targetFrameRate = 60;
    }

    void OnMouseDown()
    {
        offset = gameObject.transform.position -
            Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y));
    }
    void OnMouseDrag()
    {
        Vector3 newPosition = new Vector3(Input.mousePosition.x, Input.mousePosition.y);
        transform.position = Camera.main.ScreenToWorldPoint(newPosition) + offset;
    }
    private void OnMouseUp()
    { 
    }



}